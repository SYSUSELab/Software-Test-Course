#!/bin/bash

# 0. prepare variables
# TODO: replace with your fuzzing driver name
DRIVER_NAME="your_fuzzer_name"
DRIVER_FILE="./fuzz/${DRIVER_NAME}.cpp"
DRIVER_EXECUTABLE="fuzz/${DRIVER_NAME}"
# TODO: replace with your corpus folder
CORPUS_DIR="fuzz/corpus/"
# TODO: modify fuzz flags as needed
SOURCE_FUZZ_FLAGS="-fsanitize=address,fuzzer-no-link"
DRIVER_FUZZ_FLAGS="-fsanitize=fuzzer,address"

# 1. compile target project source
mkdir -p build
# rm -rf build/*
cd build
cmake ../json-c \
  -DCMAKE_C_COMPILER=clang \
  -DCMAKE_CXX_COMPILER=clang++ \
  -DCMAKE_C_FLAGS="-g -O1 ${SOURCE_FUZZ_FLAGS}"
make "-j$( nproc )"
cd ../

# 2. compile fuzzing driver
clang++ -g -O1 $DRIVER_FUZZ_FLAGS \
${DRIVER_FILE} \
-I./json-c \
-I./build \
./build/libjson-c.a \
-o $DRIVER_EXECUTABLE


# 3. running fuzzing driver 
# TODO: modify the parameters as needed
# mkdir -p ${CORPUS_DIR}
# mkdir -p fuzz/crashes
# ./${DRIVER_EXECUTABLE} ${CORPUS_DIR} -artifact_prefix=fuzz/crashes/ -max_total_time=60