#!/bin/bash
# Copyright (c) Huawei Technologies Co., Ltd. 2020. All rights reserved.

git checkout CMakeLists.txt
git apply huawei_zlib_CMakeList.patch
