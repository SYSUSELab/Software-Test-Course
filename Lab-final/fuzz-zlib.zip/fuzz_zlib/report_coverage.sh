#!/bin/bash

# this script reports code coverage after running the fuzzing driver

# TODO: replace with your fuzzing driver name
DRIVER_NAME="fuzz_inflate"
DRIVER_FILE="./fuzz/${DRIVER_NAME}.cpp"
DRIVER_EXECUTABLE="fuzz/${DRIVER_NAME}_cov"
# TODO: replace with your corpus folder
CORPUS_DIR="fuzz/corpus/"
# TODO: modify fuzz flags as needed
DRIVER_FUZZ_FLAGS="-fsanitize=fuzzer,address"
# TODO: set up coverage report name
REPORT_NAME="cov_html"
COVERAGE_REPORT_DIR="reports/${REPORT_NAME}"

# 1. compile target project source with coverage flags
mkdir -p build-cov
# rm -rf build-cov/*
cd build-cov
prefix=./ CC=clang CFLAGS="-g -fprofile-instr-generate -fcoverage-mapping" ./../third_party_zlib/configure
make
cd ../

# 2. compile fuzzing driver with coverage flags
clang++ -g -O1 $DRIVER_FUZZ_FLAGS -fprofile-instr-generate -fcoverage-mapping \
${DRIVER_FILE} \
-I./third_party_zlib \
-I./build-cov \
./build-cov/libz.a \
-o $DRIVER_EXECUTABLE

# 3. generate coverage report
mkdir -p ./reports
LLVM_PROFILE_FILE="./reports/cov.profraw" ./${DRIVER_EXECUTABLE} $CORPUS_DIR -runs=0
llvm-profdata merge -sparse reports/cov.profraw -o reports/cov.profdata
# if you want merge multiple profraw files, use this command:
# llvm-profdata merge -sparse reports/*.profraw -o reports/cov.profdata
llvm-cov show ./$DRIVER_EXECUTABLE \
    -instr-profile=reports/cov.profdata \
    -format=html \
    -output-dir=${COVERAGE_REPORT_DIR}