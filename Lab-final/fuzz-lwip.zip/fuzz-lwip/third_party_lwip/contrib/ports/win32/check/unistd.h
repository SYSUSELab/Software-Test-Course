#ifndef LWIP_UNISTD_H
#define LWIP_UNISTD_H

/* include io.h for read() and write() */
#include <io.h>

#endif
