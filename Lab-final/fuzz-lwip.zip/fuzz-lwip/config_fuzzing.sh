#!/bin/bash
set -euo pipefail

# 0. prepare variables
PROJECT_ROOT="$(cd "$(dirname "$0")" && pwd)"
LWIP_DIR="${PROJECT_ROOT}/third_party_lwip"
BUILD_DIR="${PROJECT_ROOT}/build/lwip_libs"
# TODO: replace with your fuzzing driver name
DRIVER_NAME="myfuzzer"
DRIVER_FILE="${PROJECT_ROOT}/fuzz/${DRIVER_NAME}.cpp"
DRIVER_EXECUTABLE="${PROJECT_ROOT}/fuzz/${DRIVER_NAME}"
# TODO: replace with your corpus folder
CORPUS_DIR="fuzz/corpus/"
# TODO: modify fuzz flags as needed
SOURCE_FUZZ_FLAGS="-fsanitize=address,fuzzer-no-link"
DRIVER_FUZZ_FLAGS="-fsanitize=fuzzer,address"

# 2. building lwIP fuzzing with CMake
LWIP_DISTRIBUTED_NET_OFF="-DLWIP_ENABLE_DISTRIBUTED_NET=0"
LWIP_INCLUDE_DIRS=(
  "${PROJECT_ROOT}/fuzz"
  "${LWIP_DIR}/test/fuzz"
  "${LWIP_DIR}/src/include"
  "${LWIP_DIR}/contrib"
  "${LWIP_DIR}/contrib/ports/unix/port/include"
)

LWIP_OPTS_PATH="${PROJECT_ROOT}/fuzz"

echo "[1/3] Configure & build lwIP libs"
cmake -S "${PROJECT_ROOT}/cmake/lwip_libs" -B "${BUILD_DIR}" \
  -DCMAKE_C_COMPILER=clang \
  -DCMAKE_CXX_COMPILER=clang++ \
  -DCMAKE_C_FLAGS="-g -O1 ${SOURCE_FUZZ_FLAGS} ${LWIP_DISTRIBUTED_NET_OFF} -Wno-empty-translation-unit -include ${PROJECT_ROOT}/fuzz/lwipopts.h -I${PROJECT_ROOT}/fuzz" \
  -DCMAKE_CXX_FLAGS="-g -O1 ${SOURCE_FUZZ_FLAGS} ${LWIP_DISTRIBUTED_NET_OFF} -Wno-empty-translation-unit -include ${PROJECT_ROOT}/fuzz/lwipopts.h -I${PROJECT_ROOT}/fuzz"

cmake --build "${BUILD_DIR}" --target lwipcore lwipallapps lwipcontribportunix -j"$(nproc)"

echo "[2/3] Build fuzz driver"
clang++ -g -O1 ${DRIVER_FUZZ_FLAGS} ${LWIP_DISTRIBUTED_NET_OFF} \
  "${DRIVER_FILE}" \
  $(printf ' -I%s' "${LWIP_INCLUDE_DIRS[@]}") \
  "${BUILD_DIR}/liblwipcore.a" \
  "${BUILD_DIR}/liblwipallapps.a" \
  "${BUILD_DIR}/liblwipcontribportunix.a" \
  -o "${DRIVER_EXECUTABLE}"

# # 3. running fuzzing driver 
# # TODO: modify the parameters as needed
# mkdir -p ${CORPUS_DIR}
# mkdir -p fuzz/crashes
# ${DRIVER_EXECUTABLE} ${CORPUS_DIR} -artifact_prefix=fuzz/crashes/ -max_total_time=60