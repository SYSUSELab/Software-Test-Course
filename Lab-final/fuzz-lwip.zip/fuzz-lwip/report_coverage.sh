#!/bin/bash
# this script reports code coverage after running the fuzzing driver
set -euo pipefail

# 0. prepare variables
PROJECT_ROOT="$(cd "$(dirname "$0")" && pwd)"
LWIP_DIR="${PROJECT_ROOT}/third_party_lwip"
BUILD_DIR="${PROJECT_ROOT}/build-cov/lwip_libs"
# TODO: replace with your fuzzing driver name
DRIVER_NAME="myfuzzer"
DRIVER_FILE="./fuzz/${DRIVER_NAME}.cpp"
DRIVER_EXECUTABLE="fuzz/${DRIVER_NAME}_cov"
# TODO: replace with your corpus folder
CORPUS_DIR="fuzz/corpus/"
# TODO: modify fuzz flags as needed
DRIVER_FUZZ_FLAGS="-fsanitize=fuzzer,address"
# TODO: set up coverage report name
REPORT_NAME="cov_html"
COVERAGE_REPORT_DIR="reports/${REPORT_NAME}"

# 1. compile target project source with coverage 
LWIP_DISTRIBUTED_NET_OFF="-DLWIP_ENABLE_DISTRIBUTED_NET=0"
LWIP_INCLUDE_DIRS=(
  "${PROJECT_ROOT}/fuzz"
  "${LWIP_DIR}/test/fuzz"
  "${LWIP_DIR}/src/include"
  "${LWIP_DIR}/contrib"
  "${LWIP_DIR}/contrib/ports/unix/port/include"
)

LWIP_OPTS_PATH="${PROJECT_ROOT}/fuzz"

echo "[1/3] Configure & build lwIP libs"
cmake -S "${PROJECT_ROOT}/cmake/lwip_libs" -B "${BUILD_DIR}" \
  -DCMAKE_C_COMPILER=clang \
  -DCMAKE_CXX_COMPILER=clang++ \
  -DCMAKE_C_FLAGS="-g -O1 -fprofile-instr-generate -fcoverage-mapping ${LWIP_DISTRIBUTED_NET_OFF} -Wno-empty-translation-unit -include ${PROJECT_ROOT}/fuzz/lwipopts.h -I${PROJECT_ROOT}/fuzz" \
  -DCMAKE_CXX_FLAGS="-g -O1 -fprofile-instr-generate -fcoverage-mapping ${LWIP_DISTRIBUTED_NET_OFF} -Wno-empty-translation-unit -include ${PROJECT_ROOT}/fuzz/lwipopts.h -I${PROJECT_ROOT}/fuzz"

cmake --build "${BUILD_DIR}" --target lwipcore lwipallapps lwipcontribportunix -j"$(nproc)"

# 2. compile fuzzing driver with coverage flags
echo "[2/3] Build fuzz driver"
clang++ -g -O1 ${DRIVER_FUZZ_FLAGS} -fprofile-instr-generate -fcoverage-mapping ${LWIP_DISTRIBUTED_NET_OFF} \
  "${DRIVER_FILE}" \
  $(printf ' -I%s' "${LWIP_INCLUDE_DIRS[@]}") \
  "${BUILD_DIR}/liblwipcore.a" \
  "${BUILD_DIR}/liblwipallapps.a" \
  "${BUILD_DIR}/liblwipcontribportunix.a" \
  -o "${DRIVER_EXECUTABLE}"

# 3. generate coverage report
mkdir -p ./reports
LLVM_PROFILE_FILE="./reports/cov.profraw" ./${DRIVER_EXECUTABLE} $CORPUS_DIR -runs=0
llvm-profdata merge -sparse reports/cov.profraw -o reports/cov.profdata
# if you want merge multiple profraw files, use this command:
# llvm-profdata merge -sparse reports/*.profraw -o reports/cov.profdata
llvm-cov show ./$DRIVER_EXECUTABLE \
    -instr-profile=reports/cov.profdata \
    -format=html \
    -output-dir=${COVERAGE_REPORT_DIR}